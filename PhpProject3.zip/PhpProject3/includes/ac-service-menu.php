<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <div class="side-menu animate-dropdown outer-bottom-xs">
    <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> Sub Categories</div>        
    <nav class="yamm megamenu-horizontal" role="navigation">
  
        <ul class="nav">
            <li class="dropdown menu-item">
              
                <a href="ac-service-menu.php"  class="dropdown-toggle" id="cat1"><i class="icon fa fa-desktop fa-fw"></i>
               Installation</a>
                <a href="C:\xampp\htdocs\PhpProject3\ac-service.php"  class="dropdown-toggle" id="cat2"><i class="icon fa fa-desktop fa-fw"></i>
               Gas Refill</a>
                <a href="ac-cat-3.php" class="dropdown-toggle" id="cat3"><i class="icon fa fa-desktop fa-fw"></i>
                    Repair</a>
                
               
                        
</li>
</ul>
    </nav>
</div>
    </body>
</html>
