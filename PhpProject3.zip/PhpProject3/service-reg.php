<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       <?php
session_start();
error_reporting(0);
include('includes/config.php');
// Code user Registration
if(isset($_POST['submit']))
{
$name=$_POST['fullname'];
$email=$_POST['emailid'];
$contactno=$_POST['contactno'];
$category=$_POST['category'];
$sub_category=$_POST['sub_category'];
$yearofexp=$_POST['yearofexp'];
$photo= addslashes(file_get_contents($_FILES['image']['tmp_name']));
$query=mysqli_query($con,"INSERT INTO `serviceprovider`(`name`, `email`, `contactno`, `category`, `subcategory`, `yearexp`, `photo`) VALUES ('$name','$email','$contactno','$category','$sub_category','$yearofexp','$photo')");
if($query)
{
	echo "<script>alert('You are successfully register');</script>";
}
else{
echo "<script>alert('Not register something went worng');</script>";
}
}




?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		<meta name="description" content="">
		<meta name="author" content="">
	    <meta name="keywords" content="MediaCenter, Template, eCommerce">
	    <meta name="robots" content="all">

	    <title>Service Registration</title>

	    <!-- Bootstrap Core CSS -->
	    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	    
	    <!-- Customizable CSS -->
	    <link rel="stylesheet" href="assets/css/main.css">
	    <link rel="stylesheet" href="assets/css/green.css">
	    <link rel="stylesheet" href="assets/css/owl.carousel.css">
		<link rel="stylesheet" href="assets/css/owl.transitions.css">
		<!--<link rel="stylesheet" href="assets/css/owl.theme.css">-->
		<link href="assets/css/lightbox.css" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/animate.min.css">
		<link rel="stylesheet" href="assets/css/rateit.css">
		<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">

		<!-- Demo Purpose Only. Should be removed in production -->
		<link rel="stylesheet" href="assets/css/config.css">

		<link href="assets/css/green.css" rel="alternate stylesheet" title="Green color">
		<link href="assets/css/blue.css" rel="alternate stylesheet" title="Blue color">
		<link href="assets/css/red.css" rel="alternate stylesheet" title="Red color">
		<link href="assets/css/orange.css" rel="alternate stylesheet" title="Orange color">
		<link href="assets/css/dark-green.css" rel="alternate stylesheet" title="Darkgreen color">
		<!-- Demo Purpose Only. Should be removed in production : END -->

		
		<!-- Icons/Glyphs -->
		<link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Fonts --> 
		<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="assets/images/favicon.ico">
<script type="text/javascript">
function valid()
{
 if(document.register.password.value!= document.register.confirmpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.register.confirmpassword.focus();
return false;
}
return true;
}
</script>
    	<script>
function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>



	</head>
    <body class="cnt-home">
	
		
	
		<!-- ============================================== HEADER ============================================== -->
<header class="header-style-1">

	<!-- ============================================== TOP MENU ============================================== -->
<?php include('includes/top-header.php');?>
<!-- ============================================== TOP MENU : END ============================================== -->

	<!-- ============================================== NAVBAR ============================================== -->
<?php include('includes/menu-bar.php');?>
<!-- ============================================== NAVBAR : END ============================================== -->
<?php include('includes/main-header.php');?>
</header>

<!-- ============================================== HEADER : END ============================================== -->
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content outer-top-bd">
	<div class="container">
		<div class="sign-in-page inner-bottom-sm">
			<div class="row">
				<!-- Sign-in -->			

<!-- Sign-in -->

<!-- create a new account -->

	<h4 class="checkout-subtitle">Service Provider Registration</h4>
	<p class="text title-tag-line"></p>
        <form enctype="multipart/form-data" class="register-form outer-top-xs" role="form" method="post" name="register" action="service-reg.php">
<div class="form-group">
	    	<label class="info-title" for="fullname">Full Name <span>*</span></label>
	    	<input type="text" class="form-control unicase-form-control text-input" id="fullname" name="fullname" required="required">
	  	</div>


		<div class="form-group">
	    	<label class="info-title" for="exampleInputEmail2">Email Address <span>*</span></label>
	    	<input type="email" class="form-control unicase-form-control text-input" id="email" onBlur="userAvailability()" name="emailid" required >
	    	       <span id="user-availability-status1" style="font-size:12px;"></span>
	  	</div>

<div class="form-group">
	    	<label class="info-title" for="contactno">Contact No. <span>*</span></label>
	    	<input type="text" class="form-control unicase-form-control text-input" id="contactno" name="contactno" maxlength="10" required >
	  	</div>

<div class="form-group">
	    	<label class="info-title" for="category">Service Category. <span>*</span></label>
	 
                <div class="category_div" id="category_div">
        <select id="category" class="form-control unicase-form-control" name="category" onchange="dynamicdropdown(this.options[this.selectedIndex].value)">
        <option value="">Select... </option>
        <option value="ac-service">AC Service</option>
        <option value="plumbing">Plumbing</option>
        <option value="home-cleaning">Home Cleaning</option>
        <option value="carpentry">Carpentry</option>
        <option value="pest-control">Pest Control</option>
        <option value="electrician">Electrician</option>
        </select>
    </div>
</div>
                <div class="form-group">
	    	<label class="info-title" for="sub_category">Sub Category. <span>*</span></label>
	 
                 <div class="sub_category_div" id="sub_category_div">
                     <select id="sub_category" class="form-control unicase-form-control" name="sub_category" >
        <option value="">Select... </option>
       
        </select>
    </div>

	  	</div>
<div class="form-group">
	    	<label class="info-title" for="yearofexp">Year of experience. <span>*</span></label>
	 
                
        <select id="category" class="form-control unicase-form-control" name="yearofexp" >
        <option value="">Select... </option>
        <option value="1-5 yrs">1-5 yrs</option>
        <option value="5-15 yrs">5-15 yrs</option>
        <option value="more than 15yrs">More than 15 yrs</option>
        </select>
    
</div>
            
<div class="form-group">
	    	<label class="info-title" for="photo">Profile Photo. <span>*</span></label>
	    	<input type="file" class="form-control unicase-form-control" id="image" name="image" required >
	  	</div>


	  	<button type="submit" name="submit" class="btn-upper btn btn-primary checkout-page-button" id="submit">Submit</button>
	</form>
	
	
<!-- create a new account -->			</div><!-- /.row -->
		</div>
<?php include('includes/brands-slider.php');?>
</div>
</div>
<?php include('includes/footer.php');?>
	<script src="assets/js/jquery-1.11.1.min.js"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>
	
	<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	
	<script src="assets/js/echo.min.js"></script>
	<script src="assets/js/jquery.easing-1.3.min.js"></script>
	<script src="assets/js/bootstrap-slider.min.js"></script>
    <script src="assets/js/jquery.rateit.min.js"></script>
    <script type="text/javascript" src="assets/js/lightbox.min.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
	<script src="assets/js/scripts.js"></script>

	<!-- For demo purposes – can be removed on production -->
	
	<script src="switchstylesheet/switchstylesheet.js"></script>
	
	<script>
            function dynamicdropdown(listindex)
    {
        switch (listindex)
        {
        case "ac-service" :
            
            document.getElementById("sub_category").options[1]=new Option("AC Repair","ac-repair");
            document.getElementById("sub_category").options[2]=new Option("Gas Refill","gas-refill");
            document.getElementById("sub_category").options[3]=new Option("Installation","installation");
            break;
        case "plumbing" :
           
            document.getElementById("sub_category").options[1]=new Option("Bathroom fittings","Bathroom-fittings");
            document.getElementById("sub_category").options[2]=new Option("Pipelines and Pumps","Pipelines-and-Pumps");
            document.getElementById("sub_category").options[3]=new Option("Tap, Wash-basin and Sink","Tap-Washbasin-and-Sink");
            break;
        case "home-cleaning" :
            
            document.getElementById("sub_category").options[1]=new Option("Kitchen and Bathroom Cleaning","Kitchen-and-Bathroom-Cleaning");
            document.getElementById("sub_category").options[2]=new Option("Floor Scrubbing and Polishing","Floor-Scrubbing-and-Polishing");
            document.getElementById("sub_category").options[3]=new Option("General Home Cleaning","General-Home-Cleaning");
            break;
        
        case "carpentry" :
            
            document.getElementById("sub_category").options[1]=new Option("Furniture Repair","Furniture-Repair");
            document.getElementById("sub_category").options[2]=new Option("Furniture Installation and Assembly","Furniture-Installation-and-Assembly");
            document.getElementById("sub_category").options[3]=new Option("General Carpentry Work","General-Carpentry-Work");
            break;
            
         case "pest-control" :
            
            document.getElementById("sub_category").options[1]=new Option("General Pest Control","General-Pest-Control");
            document.getElementById("sub_category").options[2]=new Option("Cockroach control","Cockroach-control");
             document.getElementById("sub_category").options[3]=new Option("Bed bugs control","Bed-bugs-control");
            break;
         case "electrician" :
           
            document.getElementById("sub_category").options[1]=new Option("Switches,Meters and Fuses","Switches,Meters-and-Fuses");
            document.getElementById("sub_category").options[2]=new Option("Wiring","Wiring");
            document.getElementById("sub_category").options[3]=new Option("Lights,Fans and Inverter","Lights,Fans-and-Inverter");
            break;
        }
        return true;
    }
		$(document).ready(function(){ 
			$(".changecolor").switchstylesheet( { seperator:"color"} );
			$('.show-theme-options').click(function(){
				$(this).parent().toggleClass('open');
				return false;
			});
		});

		$(window).bind("load", function() {
		   $('.show-theme-options').delay(2000).trigger('click');
		});
	</script>
	<!-- For demo purposes – can be removed on production : End -->

	

</body>
</html>
    </body>
</html>
