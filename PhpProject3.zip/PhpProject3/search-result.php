<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
session_start();
error_reporting(0);
include('includes/config.php');
$find="%{$_POST['product']}%";
$ret=mysqli_query($con,"SELECT * FROM `search-result` WHERE query LIKE '$find' ");
$num=mysqli_num_rows($ret);
if($num>0)
{
$row=mysqli_fetch_array($ret);
{
    
 if($row['result']==1)
 {
     header('location:ac-service.php?cid=1');
 }
 if($row['result']==2)
 {
     header('location:plumbing-service.php?cid=1');
 }
 if($row['result']==3)
 {
     header('location:home-service.php?cid=1');
 }
 if($row['result']==4)
 {
     header('location:carpentry-service.php?cid=1');
 }
 if($row['result']==5)
 {
     header('location:pest-service.php?cid=1');
 }
 if($row['result']==6)
 {
     header('location:electrician-service.php?cid=1');
 }
}
}
 else {
    echo "<script>alert('Sorry, No result found for $find');</script>";
    //header('location:index.php');
 }
?>			
        
    </body>
</html>
